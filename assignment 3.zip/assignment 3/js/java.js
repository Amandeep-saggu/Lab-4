
function my()
{

//  prompt box user enter the input
     var yourSong = prompt('Search for any of your favourite Song?')
// display loading sign
     var loading = document.querySelector('#loading')
      loading.style.display = 'block'


$.ajax({
    url:'https://itunes.apple.com/search?',
    data: {
  //using term as a search key for user input
    term: yourSong
    },
    dataType: 'jsonp',
    success: function (data) {
    loading.style.display = 'none'
    console.log(data)
    //renders data
    render(data)
    }
  })

  function render(data)
       {
          var ul = document.querySelector('#output')
          data.results.forEach(function (results)
         {

      var li = document.createElement('li')
          li.setAttribute('class', 'poster')
        if(results.artworkUrl100){
          var img = document.createElement('img')
          img.src = results.artworkUrl100
          li.appendChild(img)
          }
        if(results.trackName){
          var h1 = document.createElement('h1')
          h1.textContent = results.trackName
          li.appendChild(h1)
            }
      if(results.artistName){
         var h3 = document.createElement('h3')
         h3.textContent = results.artistName
         li.appendChild(h3)
          }
        if(results.trackPrice){
         var h4 = document.createElement('h4')
         h4.textContent = results.trackPrice
         li.appendChild(h4)
          }
      if(results.primaryGenreName){
         var h4 = document.createElement('h4')
         h4.textContent = results.primaryGenreName
         li.appendChild(h4)
        }
          ul.appendChild(li)
        })
      }
}
